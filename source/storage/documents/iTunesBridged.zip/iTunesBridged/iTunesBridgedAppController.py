#
#  iTunesBridgedAppController.py
#  iTunesBridged
#
#  Created by Kevin Mitchell on 1/13/08.
#  Copyright (c) 2008 __MyCompanyName__. All rights reserved.
#

from Foundation import *
from ScriptingBridge import SBApplication
from objc import ivar

def fourCharCode(x):
	return ord(x[0]) << 24 | ord(x[1]) << 16 | ord(x[2]) << 8 | ord(x[3])

# Scripting Bridge doesn't do constants yet, but we can define them by using sdef and sdp
# From iTunes.h	
# Converted with: sdef /Applications/iTunes.app/ | sdp -fh --basename iTunes 
iTunesEPlSStopped = fourCharCode('kPSS')
iTunesEPlSPlaying = fourCharCode('kPSP')
iTunesEPlSPaused = fourCharCode('kPSp')
iTunesEPlSFastForwarding = fourCharCode('kPSF')
iTunesEPlSRewinding = fourCharCode('kPSR')

class iTunesBridgedAppController(NSObject):
	iTunes = SBApplication.applicationWithBundleIdentifier_("com.apple.iTunes")
	
	trackName = ivar("trackName")
	
	def playPause_(self, sender):
		NSLog("Play/Pause")			
		self.iTunes.playpause()
		NSLog("Playing: %d" % (self.iTunes.playerState() == iTunesEPlSPlaying))
		self.trackName = self.iTunes.currentTrack().name()
		
iTunesBridgedAppController.exposeBinding_("trackName")