#
#  iTunesBridgedAppDelegate.py
#  iTunesBridged
#
#  Created by Kevin Mitchell on 1/13/08.
#  Copyright __MyCompanyName__ 2008. All rights reserved.
#

from Foundation import *
from AppKit import *

class iTunesBridgedAppDelegate(NSObject):
    def applicationDidFinishLaunching_(self, sender):
        NSLog("Application did finish launching.")
